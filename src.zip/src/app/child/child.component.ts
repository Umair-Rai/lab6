import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  standalone: true
})
export class ChildComponent {
  @Input() users: string[] = [];
  @Output() removeUser = new EventEmitter<void>();

  onRemoveUser() {
    this.removeUser.emit(); // Emit event to the parent to remove the user
  }
}
