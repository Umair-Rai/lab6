import { Component } from '@angular/core';
import {ChildComponent} from '../child/child.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  imports: [
    ChildComponent
  ],
  standalone: true
})
export class ParentComponent {
  users: string[] = ['user1', 'user2', 'user3'];

  addUser() {
    const newUser = `user${this.users.length + 1}`; // Generate a new user name
    this.users.push(newUser);
  }

  removeUser() {
    if (this.users.length > 0) {
      this.users.shift(); // Remove the first user
    }
  }
}
